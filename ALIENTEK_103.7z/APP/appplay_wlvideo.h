#ifndef __APPPLAY_WLVIDEO_H
#define __APPPLAY_WLVIDEO_H
#include "common.h"






u8 appplay_wlvideo(u8* caption);
#endif



